package com.zys.yskc.videoplayer;

import com.jia.jsplayer.danmu.DanmuModel;

/**
 * @author zhaoyasong
 * @date 09/11/2017 16:29
 * @description
 */
public class MyDanmuModel extends DanmuModel{
    public String content;
    public int goodNum;
    public boolean isGood;
    
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public int getGoodNum() {
        return goodNum;
    }
    
    public void setGoodNum(int goodNum) {
        this.goodNum = goodNum;
    }
    
    public boolean isGood() {
        return isGood;
    }
    
    public void setGood(boolean good) {
        isGood = good;
    }
}
