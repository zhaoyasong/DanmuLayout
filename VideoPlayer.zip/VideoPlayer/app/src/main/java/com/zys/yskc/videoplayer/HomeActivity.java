package com.zys.yskc.videoplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.jia.jsplayer.listener.OnVideoControlListener;
import com.jia.jsplayer.utils.DisplayUtils;
import com.jia.jsplayer.video.JsPlayer;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    private String path = "http://baobab.wdjcdn.com/1455782903700jy.mp4";
    private JsPlayer mJsPlayer;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        
    }
    
    private void init() {
        initView();
        //初始化播放器
        initPlayer();
    }
    
    private void initPlayer() {
        mJsPlayer.setOnVideoControlListener(new OnVideoControlListener() {
            @Override
            public void onStartPlay() {
                mJsPlayer.startPlay();
            }
    
            @Override
            public void onBack() {
        
            }
    
            @Override
            public void onFullScreen() {
                DisplayUtils.toggleScreenOrientation(HomeActivity.this);
            }
    
            @Override
            public void onRetry(int errorStatus) {
        
            }
        });
        
        //设置播放路径和视频的标题
        mJsPlayer.setPath(new VideoInfo("赵二狗的幸福生活",path));
    }
    
    private void initView() {
        mJsPlayer = (JsPlayer) findViewById(R.id.player);
        Button jumpDM = (Button) findViewById(R.id.bt_danmu);
        jumpDM.setOnClickListener(this);
        
    }
    
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bt_danmu:
                //跳转弹幕的界面
                Intent intent = new Intent(HomeActivity.this, DanmuActivity.class);
                startActivity(intent);
                break;
            
            default:
                break;
        }
    }
    
    @Override
    protected void onStop() {
        super.onStop();
        mJsPlayer.onStop();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mJsPlayer.onDestroy();
    }
}
