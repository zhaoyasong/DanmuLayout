package com.zys.yskc.videoplayer;

import com.jia.jsplayer.bean.IVideoInfo;

/**
 * @author zhaoyasong
 * @date 09/11/2017 16:16
 * @description
 */
public class VideoInfo implements IVideoInfo{
    private String videoTitle;
    private String videoPath;
    
    public VideoInfo(String videoTitle, String videoPath) {
        this.videoTitle = videoTitle;
        this.videoPath = videoPath;
    }
    
    public String getVideoTitle() {
        return videoTitle;
    }
    
    
    public String getVideoPath() {
        return videoPath;
    }

}
