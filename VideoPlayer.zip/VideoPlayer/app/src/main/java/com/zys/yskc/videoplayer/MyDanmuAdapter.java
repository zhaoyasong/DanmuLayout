package com.zys.yskc.videoplayer;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.jia.jsplayer.danmu.DanmuAdapter;
import com.wx.goodview.GoodView;

/**
 * @author zhaoyasong
 * @date 09/11/2017 16:31
 * @description 创建弹幕的适配器
 */
public class MyDanmuAdapter extends DanmuAdapter<MyDanmuModel> {
    
    private Context context;
    
    public MyDanmuAdapter(Context context) {
        super();
        this.context = context;
    }
    
    /**
     * 获取类型数组
     *
     * @return
     */
    @Override
    public int[] getViewTypeArray() {
        int type[]  = {0,1,2,3};
        return type;
    }
    
    /**
     * 获取单行弹幕 高度
     *
     * @return
     */
    @Override
    public int getSingleLineHeight() {
        View view = LayoutInflater.from(context).inflate(R.layout.item_danmu, null);
        view.measure(0,0);
        return view.getMeasuredHeight();
    }
    
    /**
     * 获取itemView
     *
     * @param entry
     * @param convertView
     * @return
     */
    @Override
    public View getView(final MyDanmuModel entry, View convertView) {
        ViewHolder vh = null;
        if (convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.item_danmu, (ViewGroup) convertView, true);
            vh = new ViewHolder();
            vh.tv = (TextView) convertView.findViewById(R.id.tv_danmu);
            vh.iv_danmu_img = (ImageView) convertView.findViewById(R.id.iv_danmu_img);
            vh.iv_danmu_good = (ImageView) convertView.findViewById(R.id.iv_danmu_good);
            vh.tv_good_num = (TextView) convertView.findViewById(R.id.tv_good_num);
            convertView.setTag(vh);
        }else {
            vh = (ViewHolder) convertView.getTag();
        }
        
        switch (entry.getType()){
            case 0:
                vh.iv_danmu_img.setImageResource(R.mipmap.q);
                break;
            case 1:
                vh.iv_danmu_img.setImageResource(R.mipmap.w);
                break;
            case 2:
                vh.iv_danmu_img.setImageResource(R.mipmap.e);
                break;
            case 3:
                vh.iv_danmu_img.setImageResource(R.mipmap.r);
                break;
            default:
                break;
        }
        
        vh.tv.setText(entry.getContent() + "");
        vh.tv.setTextSize(textSize);
        
        vh.tv_good_num.setText(entry.getGoodNum() + "");
        if (entry.isGood()){
            vh.iv_danmu_good.setImageResource(R.mipmap.good_on);
        }else {
            vh.iv_danmu_good.setImageResource(R.mipmap.good_off);
        }
        
        vh.tv.setAlpha(alpha);
        vh.tv_good_num.setAlpha(alpha);
        vh.iv_danmu_good.setAlpha(alpha);
        vh.iv_danmu_good.setAlpha(alpha);
        vh.iv_danmu_img.setAlpha(alpha);
    
    
        final ViewHolder finalVh = vh;
        vh.tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (entry.isGood()) {
                    return;
                }
                entry.setGood(true);
                finalVh.tv_good_num.setText((entry.getGoodNum() + 1) + "");
                finalVh.tv_good_num.setTextColor(Color.RED);
                finalVh.tv.setTextColor(Color.RED);
                finalVh.iv_danmu_good.setImageResource(R.mipmap.good_on);
            
                GoodView goodView = new GoodView(context);
                goodView.setTextInfo("+1", Color.parseColor("#f66467"), 12);
                goodView.show(view);
            }
        });
    
        return convertView;
    }
    
    
    class ViewHolder{
        ImageView iv_danmu_img;
        TextView tv;
        ImageView iv_danmu_good;
        TextView tv_good_num;
    }
    
    private int textSize = 15;
    private float alpha = 1.0f;
    
    public int getTextSize() {
        return textSize;
    }
    
    public void setTextSize(int textSize) {
        this.textSize = textSize;
        
    }
    
    public float getAlpha() {
        return alpha;
    }
    
    public void setAlpha(float alpha) {
        this.alpha = alpha;
    }
}
