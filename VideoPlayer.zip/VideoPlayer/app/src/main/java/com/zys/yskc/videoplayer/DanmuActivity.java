package com.zys.yskc.videoplayer;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

import com.jia.jsplayer.danmu.DanmuView;
import com.jia.jsplayer.listener.OnVideoControlListener;
import com.jia.jsplayer.utils.DisplayUtils;
import com.jia.jsplayer.video.JsPlayer;

import java.util.Random;

import static com.zys.yskc.videoplayer.R.id.bt_add_danmu;
import static com.zys.yskc.videoplayer.R.id.jsplayer_danmu;

public class DanmuActivity extends AppCompatActivity {
    
    public String DANMU[] = {"腌疙瘩，炸麻叶", "一种鸡蛋蒸虾酱", "鲜味妙不可言", "撒了芝麻的吊炉烧饼，焦香四溢", "西红柿鸡蛋面", "那浓郁深沉的酱油味仍然让我无比想念", "即使是二姨炒的土豆片", "蒸馍馍"};
    public int COLOR[] = {Color.BLUE, Color.WHITE, Color.YELLOW, Color.RED};
    private String path = "http://baobab.wdjcdn.com/1455782903700jy.mp4";
    
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 1){
                handler.sendEmptyMessageAtTime(1,250);
            }
        }
    };
    private Random random;
    private JsPlayer mJsPlayer_danmu;
    private Button mAdd_danmu;
    private Button mDanmu_setting;
    private SeekBar seek_light;
    private SeekBar seek_speed;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danmu);
        
        random = new Random();
        mJsPlayer_danmu = (JsPlayer) findViewById(jsplayer_danmu);
        mAdd_danmu = (Button) findViewById(bt_add_danmu);
        mDanmu_setting = (Button) findViewById(R.id.bt__danmu_setting);
    
        seek_light = (SeekBar) findViewById(R.id.seek_light);
        seek_light.setMax(255);
        seek_speed = (SeekBar) findViewById(R.id.seek_speed);
        seek_speed.setMax(8);
    
        seek_speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
            
            }
        
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            
            }
        
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mJsPlayer_danmu.setDanMuSpeed(seekBar.getProgress());
            }
        });
    
        seek_light.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
            
            }
        
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            
            }
        
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mJsPlayer_danmu.getDanmu().setAlpha(255 - seekBar.getProgress());
            }
        });
    
        mJsPlayer_danmu.setOnVideoControlListener(new OnVideoControlListener() {
            @Override
            public void onStartPlay() {
                mJsPlayer_danmu.startPlay();
            }
        
            @Override
            public void onBack() {
            
            }
        
            @Override
            public void onFullScreen() {
                DisplayUtils.toggleScreenOrientation(DanmuActivity.this);
            }
        
            @Override
            public void onRetry(int errorStatus) {
            
            }
        });
    
        mJsPlayer_danmu.setPath(new VideoInfo("极品艺术", path));
    
        mJsPlayer_danmu.setDanMuAdapter(new MyDanmuAdapter(this));
        mJsPlayer_danmu.setDanMuGravity(3);
        mJsPlayer_danmu.setDanMuSpeed(DanmuView.NORMAL_SPEED);
    
        mAdd_danmu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDanmuModel danmuEntity = new MyDanmuModel();
                danmuEntity.setContent(DANMU[random.nextInt(8)]);
                danmuEntity.setType(random.nextInt(4));
                danmuEntity.setGoodNum(random.nextInt(100) + 1);
                danmuEntity.setGood(false);
                mJsPlayer_danmu.addDanmu(danmuEntity);
            }
        });
    }
    
    
    
}
