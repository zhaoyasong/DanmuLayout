package com.jia.jsplayer.danmu;

/**
 * Description: 弹幕实体类
 * Created by jia on 2017/9/25.
 * 人之所以能，是相信能
 */
public class DanmuModel {

    private int type;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
