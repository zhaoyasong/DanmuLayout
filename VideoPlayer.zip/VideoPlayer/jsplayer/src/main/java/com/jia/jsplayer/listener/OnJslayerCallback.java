package com.jia.jsplayer.listener;

import android.media.MediaPlayer;

public class OnJslayerCallback implements OnPlayerCallback {

    @Override
    public void onPrepared(MediaPlayer mp) {

    }

    @Override
    public void onBufferingUpdate(MediaPlayer mp, int percent) {

    }

    @Override
    public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {

    }

    @Override
    public void onCompletion(MediaPlayer mp) {

    }

    @Override
    public void onError(MediaPlayer mp, int what, int extra) {

    }

    @Override
    public void onLoadingChanged(boolean isShow) {

    }

    @Override
    public void onStateChanged(int curState) {

    }
}
