package com.jia.jsplayer.listener;

public class OnJsVideoControlListener implements OnVideoControlListener {

    @Override
    public void onStartPlay() {

    }

    @Override
    public void onBack() {

    }

    @Override
    public void onFullScreen() {

    }

    @Override
    public void onRetry(int errorStatus) {

    }
}
